from restaurant import Restaurant

if __name__ == "__main__":
    visiting_period = 5

    restaurant = Restaurant(visiting_period)
    restaurant.run()