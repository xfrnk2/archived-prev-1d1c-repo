from abc import *

class RestaurantObject(ABC):

    @abstractmethod
    def update(self):
        pass
